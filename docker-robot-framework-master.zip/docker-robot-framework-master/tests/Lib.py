from selenium import webdriver

class Lib:
    def create_firefox_profile(self, profile_path):
        fp = webdriver.FirefoxProfile(profile_path)
        fp.set_preference("security.default_personal_cert", "Select Automatically")
        return fp
